Dashboard = React.createClass({
    render() {
        return (
            <div>
                <h1>This is the Dashboard</h1>
            </div>
        )
    }
});