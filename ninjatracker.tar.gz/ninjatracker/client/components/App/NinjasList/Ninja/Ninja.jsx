Ninja = React.createClass({
    render() {
        return (
        <div className="col-xs-12 col-sm-6">
            <div className="panel panel-default">
                <div className="panel-heading">
                    <h3>Ninja Name</h3>
                </div>
                <div className="panel-body">
                    <h4>Score: 95</h4>
                    <h4>Current Status: Available</h4>
                    <h4>Jobs Completed: 31</h4>
                </div>
            </div>
        </div>
        )
    }
});