RequestForm = React.createClass({
    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-xs-10 col-xs-offset-1">
                        <h1>Form goes here</h1>
                    </div>
                </div>
            </div>
        )
    }
});