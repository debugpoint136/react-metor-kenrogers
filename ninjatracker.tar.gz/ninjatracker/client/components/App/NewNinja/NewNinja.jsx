NewNinja = React.createClass({
    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-xs-12">
                        <h1>New Ninja Form</h1>
                    </div>
                </div>
            </div>
        )
    }
});